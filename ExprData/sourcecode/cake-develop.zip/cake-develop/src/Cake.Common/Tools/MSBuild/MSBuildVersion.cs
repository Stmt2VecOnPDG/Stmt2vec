﻿namespace Cake.Common.Tools.MSBuild
{
    internal enum MSBuildVersion
    {
        MSBuild20 = 1,
        MSBuild35 = 2,
        MSBuild4 = 3,
        MSBuild12 = 4,
        MSBuild14 = 5
    }
}