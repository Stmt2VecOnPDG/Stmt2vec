﻿namespace Cake.Common.Tools.DotNetCore.Execute
{
    /// <summary>
    /// Contains settings used by <see cref="DotNetCoreExecutor" />.
    /// </summary>
    public sealed class DotNetCoreExecuteSettings : DotNetCoreSettings
    {
    }
}
