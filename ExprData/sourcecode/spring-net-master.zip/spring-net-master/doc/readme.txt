This Docbook documentation was taken from the Spring.Java project. The
documentation can be generated using Java Ant. The targets are:

* docpdf        - generates the PDF documentation
* dochtml       - generates the HTML documentation
* dochtmlsingle - generates single page HTML documentation
* clean         - clean any output directories for docs

To generate documentation, you need to include a lot of libraries, which
haven't been added to CVS because they're simply too big. 

Refer to the Spring.NET Wiki at
http://opensource.atlassian.com/confluence/spring/display/NET/Docbook+Reference
for information on how to install the docbook toolchain.

Thanks to Spring.Java and Hibernate, for providing the skeleton for DocBook
documentation!

choy@rcn.com

