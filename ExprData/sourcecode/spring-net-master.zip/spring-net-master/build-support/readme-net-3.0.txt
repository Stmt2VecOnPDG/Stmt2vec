Spring.NET 1.3.2 supports .NET 1.1, 2.0, 3.0, 3.5, and 4.0

To use Spring.NET with .NET 3.0 use the Spring.Services.dll in the bin\net\3.0\debug or bin\net\3.0\release directory.  

All other Spring DLLs should be taken from the directory bin\net\2.0\debug or bin\net\3.0\release.  

The Spring.Services.dll in the bin\net\3.0 directory is built against Spring DLLs in the corresponding bin\net\2.0 directory.

