﻿using Orchard.Core.Common.Settings;

namespace Orchard.Core.Common.ViewModels {
    public class TextFieldSettingsEventsViewModel {
        public TextFieldSettings Settings { get; set; }
    }
}