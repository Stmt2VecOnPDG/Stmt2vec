﻿namespace Orchard.Core.Common.ViewModels {
    public class ContainerEditorViewModel {

        public int? ContainerId { get; set; }
    }
}