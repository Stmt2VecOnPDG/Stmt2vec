﻿using Orchard.ContentManagement;

namespace Orchard.Core.Navigation.Models {
    public class BreadcrumbMenuItemPart : ContentPart {
    }
}