using Orchard.ContentManagement.Records;

namespace Orchard.Tests.ContentManagement.Records {
    public class GammaRecord : ContentPartRecord {
        public virtual string Frap { get; set; }
    }
}