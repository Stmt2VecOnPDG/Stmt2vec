﻿using Orchard.ContentManagement;

namespace Orchard.Tests.ContentManagement.Models {
    public class EpsilonPart : ContentPart<EpsilonRecord> {
    }
}
