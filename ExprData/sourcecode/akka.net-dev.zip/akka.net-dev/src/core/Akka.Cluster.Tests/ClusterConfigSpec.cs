﻿//-----------------------------------------------------------------------
// <copyright file="ClusterConfigSpec.cs" company="Akka.NET Project">
//     Copyright (C) 2009-2016 Lightbend Inc. <http://www.lightbend.com>
//     Copyright (C) 2013-2016 Akka.NET project <https://github.com/akkadotnet/akka.net>
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Immutable;
using Akka.Actor;
using Akka.Remote;
using Akka.TestKit;
using Xunit;
using Assert = Xunit.Assert;

namespace Akka.Cluster.Tests
{
    public class ClusterConfigSpec : AkkaSpec
    {
        public ClusterConfigSpec() : base(@"akka.actor.provider = ""Akka.Cluster.ClusterActorRefProvider, Akka.Cluster""") { }

        [Fact]
        public void Clustering_must_be_able_to_parse_generic_cluster_config_elements()
        {
            var settings = new ClusterSettings(Sys.Settings.Config, Sys.Name);
            Assert.True(settings.LogInfo);
            Assert.Equal(8, settings.FailureDetectorConfig.GetDouble("threshold"));
            Assert.Equal(1000, settings.FailureDetectorConfig.GetInt("max-sample-size"));
            Assert.Equal(TimeSpan.FromMilliseconds(100), settings.FailureDetectorConfig.GetTimeSpan("min-std-deviation"));
            Assert.Equal(TimeSpan.FromSeconds(3), settings.FailureDetectorConfig.GetTimeSpan("acceptable-heartbeat-pause"));
            Assert.Equal(typeof(PhiAccrualFailureDetector), Type.GetType(settings.FailureDetectorImplementationClass));
            Assert.Equal(ImmutableList.Create<Address>(), settings.SeedNodes);
            Assert.Equal(TimeSpan.FromSeconds(5), settings.SeedNodeTimeout);
            Assert.Equal(TimeSpan.FromSeconds(10), settings.RetryUnsuccessfulJoinAfter);
            Assert.Equal(TimeSpan.FromSeconds(1), settings.PeriodicTasksInitialDelay);
            Assert.Equal(TimeSpan.FromSeconds(1), settings.GossipInterval);
            Assert.Equal(TimeSpan.FromSeconds(2), settings.GossipTimeToLive);
            Assert.Equal(TimeSpan.FromSeconds(1), settings.HeartbeatInterval);
            Assert.Equal(5, settings.MonitoredByNrOfMembers);
            Assert.Equal(TimeSpan.FromSeconds(5), settings.HeartbeatExpectedResponseAfter);
            Assert.Equal(TimeSpan.FromSeconds(1), settings.LeaderActionsInterval);
            Assert.Equal(TimeSpan.FromSeconds(1), settings.UnreachableNodesReaperInterval);
            Assert.Null(settings.PublishStatsInterval);
            Assert.Null(settings.AutoDownUnreachableAfter);
            Assert.Equal(1, settings.MinNrOfMembers);
            //TODO:
            //Assert.AreEqual(ImmutableDictionary.Create<string, int>(), settings.);
            Assert.Equal(ImmutableHashSet.Create<string>(), settings.Roles);
            Assert.Equal("akka.cluster.default-cluster-dispatcher", settings.UseDispatcher);
            Assert.Equal(.8, settings.GossipDifferentViewProbability);
            Assert.Equal(400, settings.ReduceGossipDifferentViewProbability);
            Assert.Equal(TimeSpan.FromMilliseconds(33), settings.SchedulerTickDuration);
            Assert.Equal(512, settings.SchedulerTicksPerWheel);
            Assert.True(settings.MetricsEnabled);
            //TODO:
            //Assert.AreEqual(typeof(SigarMetricsCollector).FullName, settings.MetricsCollectorClass);
            Assert.Equal(TimeSpan.FromSeconds(3), settings.MetricsGossipInterval);
            Assert.Equal(TimeSpan.FromSeconds(12), settings.MetricsMovingAverageHalfLife);
            Assert.Equal(false, settings.VerboseHeartbeatLogging);
        }

        [Fact]
        public void Clustering_should_have_correct_default_fork_join_dispatcher()
        {
            var dispatchConfig = Sys.Settings.Config.GetConfig("akka.cluster.default-cluster-dispatcher");
            var dispatcherThreadPoolSettings = dispatchConfig.GetConfig("dedicated-thread-pool");

            var dispatcherType = dispatchConfig.GetString("type");
            var threadCount = dispatcherThreadPoolSettings.GetInt("thread-count");

            Assert.Equal("ForkJoinDispatcher", dispatcherType);
            Assert.Equal(4, threadCount);
        }
    }
}