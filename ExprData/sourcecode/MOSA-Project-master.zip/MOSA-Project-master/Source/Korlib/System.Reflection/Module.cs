﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace System.Reflection
{
	public class Module
	{
		public virtual Assembly Assembly
		{
			get { throw new NotImplementedException(); }
		}
	}
}
