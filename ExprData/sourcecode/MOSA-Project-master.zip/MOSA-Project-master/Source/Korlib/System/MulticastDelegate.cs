﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace System
{
	/// <summary>
	/// Implementation of the "System.MulticastDelegate" class.
	/// </summary>
	public class MulticastDelegate : Delegate
	{
	}
}
