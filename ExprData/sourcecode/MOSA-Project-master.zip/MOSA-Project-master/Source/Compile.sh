#cp ../3rdParty/*.dll ../bin/
xbuild
