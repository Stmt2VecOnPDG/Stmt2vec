﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

using System;

namespace Mosa.Compiler.Framework.CIL
{
	/// <summary>
	///
	/// </summary>
	public sealed class StlocInstruction : StoreInstruction
	{
		#region Construction

		/// <summary>
		/// Initializes a new instance of the <see cref="StlocInstruction"/> class.
		/// </summary>
		public StlocInstruction(OpCode opcode)
			: base(opcode)
		{
		}

		#endregion Construction

		#region Methods

		/// <summary>
		/// Stloc has a result, but doesn't push it on the stack.
		/// </summary>
		/// <value><c>true</c> if [push result]; otherwise, <c>false</c>.</value>
		public override bool PushResult
		{
			get { return false; }
		}

		/// <summary>
		/// Decodes the specified instruction.
		/// </summary>
		/// <param name="ctx">The context.</param>
		/// <param name="decoder">The instruction decoder, which holds the code stream.</param>
		public override void Decode(InstructionNode ctx, IInstructionDecoder decoder)
		{
			// Decode base classes first
			base.Decode(ctx, decoder);

			int index;

			// Destination depends on the opcode
			switch (opcode)
			{
				case OpCode.Stloc:
				case OpCode.Stloc_s: index = (int)decoder.Instruction.Operand; break;
				case OpCode.Stloc_0: index = 0; break;
				case OpCode.Stloc_1: index = 1; break;
				case OpCode.Stloc_2: index = 2; break;
				case OpCode.Stloc_3: index = 3; break;
				default: throw new NotImplementedException();
			}

			ctx.Result = decoder.Compiler.GetLocalOperand(index);
		}

		#endregion Methods
	}
}
