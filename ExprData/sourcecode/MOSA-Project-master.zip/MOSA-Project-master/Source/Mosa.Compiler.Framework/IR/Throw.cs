﻿// Copyright (c) MOSA Project. Licensed under the New BSD License.

namespace Mosa.Compiler.Framework.IR
{
	/// <summary>
	///
	/// </summary>
	public sealed class Throw : OneOperandInstruction
	{
	}
}
