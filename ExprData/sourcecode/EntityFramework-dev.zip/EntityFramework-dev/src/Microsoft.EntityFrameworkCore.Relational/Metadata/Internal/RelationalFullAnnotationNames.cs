// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

namespace Microsoft.EntityFrameworkCore.Metadata.Internal
{
    /// <summary>
    ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
    ///     directly from your code. This API may change or be removed in future releases.
    /// </summary>
    public class RelationalFullAnnotationNames
    {
        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        protected RelationalFullAnnotationNames(string prefix)
        {
            ColumnName = prefix + RelationalAnnotationNames.ColumnName;
            ColumnType = prefix + RelationalAnnotationNames.ColumnType;
            DefaultValueSql = prefix + RelationalAnnotationNames.DefaultValueSql;
            ComputedColumnSql = prefix + RelationalAnnotationNames.ComputedColumnSql;
            DefaultValue = prefix + RelationalAnnotationNames.DefaultValue;
            DatabaseName = prefix + RelationalAnnotationNames.DatabaseName;
            TableName = prefix + RelationalAnnotationNames.TableName;
            Schema = prefix + RelationalAnnotationNames.Schema;
            DefaultSchema = prefix + RelationalAnnotationNames.DefaultSchema;
            Name = prefix + RelationalAnnotationNames.Name;
            SequencePrefix = prefix + RelationalAnnotationNames.SequencePrefix;
            DiscriminatorProperty = prefix + RelationalAnnotationNames.DiscriminatorProperty;
            DiscriminatorValue = prefix + RelationalAnnotationNames.DiscriminatorValue;
        }

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public static RelationalFullAnnotationNames Instance { get; } = new RelationalFullAnnotationNames(RelationalAnnotationNames.Prefix);

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string ColumnName;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string ColumnType;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string DefaultValueSql;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string ComputedColumnSql;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string DefaultValue;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string DatabaseName;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string TableName;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string Schema;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string DefaultSchema;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string Name;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string SequencePrefix;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string DiscriminatorProperty;

        /// <summary>
        ///     This API supports the Entity Framework Core infrastructure and is not intended to be used 
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public readonly string DiscriminatorValue;
    }
}
