// Empty DirectXMath as it doesn't parse well with gccxml

#pragma once

namespace DirectX
{

struct XMFLOAT3
{
    float x;
    float y;
    float z;
};

}; // namespace DirectX

