Redistributable file for D3DCompiler_46.dll and D3DCsx_46.dll.
See http://blogs.msdn.com/b/chuckw/archive/2012/05/07/hlsl-fxc-and-d3dcompile.aspx for more information.
