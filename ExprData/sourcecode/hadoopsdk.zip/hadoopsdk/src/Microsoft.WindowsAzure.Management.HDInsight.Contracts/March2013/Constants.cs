﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.WindowsAzure.Management.HDInsight.Contracts.March2013
{
    public static class Constants
    {
        public const string XsdNamespace = "http://schemas.datacontract.org/2004/07/Microsoft.ClusterServices.DataAccess.Context";
        public const string XsdMetastoreNamespace = "http://schemas.datacontract.org/2004/07/Microsoft.ClusterServices.DataAccess";
    }
}
