﻿//-----------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//-----------------------------------------------------------

namespace Microsoft.WindowsAzure.Management.HDInsight.Contracts.March2013
{
    public enum ClusterNodeType
    {
        HeadNode,
        DataNode,
    }
}
