﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.WindowsAzure.Management.HDInsight.Contracts.May2013
{
    public static class Constants
    {
        public const string XsdNamespace = "http://schemas.microsoft.com/hdinsight/2013/05/management";
    }
}
