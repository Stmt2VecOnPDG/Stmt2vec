﻿//-----------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//-----------------------------------------------------------

namespace Microsoft.WindowsAzure.Management.HDInsight.Contracts.May2013
{
    public enum ClusterRoleType
    {
        HeadNode,
        DataNode,
    }
}
